# Preliminary Analysis of RNAseq Data
# The following code:
# installs and loads libraries
# downloads and associates transcript ids with gene names
# generates and exports a combined RawCountData file
# provides an initial glance at RAW gene expression patterns


# To prepare for the teaching demonstration, run lines 11 - 31

# Install and Load Libraries:----

# Bioconductor libraries:
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("tximport")
BiocManager::install("DESeq2")
BiocManager::install("biomaRt")

library(tximport)
library(DESeq2)
library(biomaRt)


# R libaries:

if (!require("pacman", quietly = TRUE))
  install.packages("pacman")

pacman::p_load(tidyverse, Rmisc)

###
# # Retrieve Gene Annotation Information:----

# link to annotation database and dataset for D. melanogaster
map_mart <- biomaRt::useMart(biomart = "ENSEMBL_MART_ENSEMBL", 
                             dataset = "dmelanogaster_gene_ensembl", 
                             host = "https://www.ensembl.org")				

# retrieve information from BioMart database
t2g <- biomaRt::getBM(attributes=c("ensembl_transcript_id","external_gene_name"), mart = map_mart)
head(t2g)


###

# Load Sample Data Files:----

# load file with sample-specific information
SampleList <- read.table("results/DE_analysis/SampleList.txt", header = TRUE)

# list all directories containing sample quant data
samples <- list.files(path = "./results/salmon", full.names = TRUE)

# generate a vector of all filenames including the path 
files <- file.path(samples, "quant.sf")
names(files) <- str_replace(samples, "results/salmon/", "") %>% 
  str_replace("./", "") %>% 
  str_replace("_quant", "")

head(files) # a named vector with the path to each file and the corresponding SRR name

# Use txi to Read in Data:
txi <- tximport(files, type = "salmon", tx2gene = t2g, countsFromAbundance = "lengthScaledTPM")
attributes(txi)

# save the count matrix as a data frame
count.data <- txi$counts %>% 
  data.frame()
head(count.data)

# write.table(count.data, "results/DE_analysis/RawCountData.txt", sep = "\t", quote = FALSE)
# (IF NEEDED, READ IN BACKUP COUNT FILE)
# count.data <- read.table("results/DE_analysis/RawCountData.txt", row.names = 1)
# head(count.data)



# convert from wide to long format for easier plotting:
count.data.long <- count.data %>% 
  rownames_to_column(var = "Gene") %>% 
  pivot_longer(cols = -Gene, names_to = "Sample", values_to = "Raw_Count")

# add sample information:
count.data.long <- left_join(count.data.long, SampleList, by = "Sample")
head(count.data.long)

###
# Preliminary Data Exploration:----

# Visualize clustering of the samples:
RawCounts.pca <- prcomp(t(count.data))
RC.pca.df <- data.frame(RawCounts.pca$x)
head(RC.pca.df)

# Associate pc data with sample information:
RC.pca.df <- RC.pca.df %>% 
  rownames_to_column(var = "Sample") %>% 
  left_join(SampleList, by = "Sample")

head(RC.pca.df)

# Generate a plot of sample clustering
ggplot(RC.pca.df, aes(PC1, PC2, color = Treatment)) +
  geom_point() +
  stat_ellipse(geom = "polygon", aes(fill = Treatment), alpha = 0.2, level = 0.95, show.legend = FALSE) +
  theme_classic()



# Gene expression variation in Metallothioneins (expecting upregulation under copper stress):
count.CopperGenes <- subset(count.data.long, Gene %in% c("MtnA","MtnB","MtnC","MtnD","MtnE"))

ggplot(count.CopperGenes, aes(Treatment, Raw_Count, fill = Treatment)) +
  geom_boxplot() +
  facet_grid(~Gene) +
  theme_classic() +
  theme(legend.position = c(0.9,0.9))

# Calculate basic summary metrics for gene expression of Metallothioneins:
count.CopperGenes.avg <- summarySE(count.CopperGenes, measurevar = "Raw_Count", groupvars = c("Gene","Treatment"))
count.CopperGenes.avg

ggplot(count.CopperGenes.avg, aes(Treatment, Raw_Count, color = Treatment)) +
  geom_errorbar(aes(ymin = Raw_Count - se, ymax = Raw_Count + se), width = 0.1) +
  geom_point() +
  facet_grid(~Gene) +
  theme_classic()  +
  theme(legend.position = c(0.9,0.9))

