#!/bin/bash

# INSTRUCTIONS:
# Modify template and save as STEP3_RNAseq_Pipeline.sh


echo "Sourcing the config file"
source ~/Desktop/Bioinformatics_Teaching_Demo/scripts/STEP1_RNAseq_config.sh

###################################
#  Index Reference Transcriptome  #
###################################
# Set REF_GENOME variable
REF_GENOME=${REFS_DIR}/dmel-transcriptome.fasta.gz

# check if the INDEXED TRANSCRIPTOME exists already
# if yes, skip indexing: if directory -d does not (!) exist, proceed.

if [[ ! -d "${REFS_DIR}/dmel_idx" ]]; then
	echo "Indexing Reference Transcriptome"






else
  echo "Index found; skipping indexing step"
fi




#########################
# FASTP Quality Control #
#########################
# check if the filtered FASTQ file (-f) exists already
# if yes, skip filtering: if file -f does not (!) exist, proceed.










###################
# MULTIQC Summary #
###################
# check if the MULTIQC report html (-f) exists already
# if yes, skip summarizing: if file -f does not (!) exist, proceed.








###########################
#  Quantify Sample Reads  #
###########################

# Set INDEX variable
INDEX=${REFS_DIR}/dmel_idx
