#!/bin/bash

# This script:
  # downloads sample and reference data
  # performs quality checks and trimming of sample reads
  # indexes the transcriptome reference
  # aligns and quantifies sample reads



# INSTRUCTIONS:
# Modify template and save as STEP2_RNAseq_Pipeline.sh
# Comment in/out short cut: mac cmd/  windows ctl/
# sh STEP2_RNAseq_Pipeline.sh

echo "Sourcing the config file"
source ~/Downloads/RNAseq_Pipeline/scripts/STEP1_RNAseq_config.sh




#####################################
# Download SAMPLE DATA from github: #
#####################################

if [[ ! -f "${DATA_RAW}/SRR11799546.2.sub.fastq.gz" ]]; then
	echo "Downloading Data from GitHub"

	cd ${DATA_RAW}

  xargs -n 1 curl -O < ${SCRIPTS_DIR}/SRR_urls.txt || { echo "data download failed" ; exit 1; }

else
  echo "Sample data found; skipping sample data download step"
fi


######################################################
# Download TRANSCRIPTOME for salmon pseudoalignment: #
######################################################

if [[ ! -f "${REFS_DIR}/dmel-all-transcript-r6.44.fasta.gz" ]]; then
	echo "Downloading Reference Transcriptome"

	cd ${REFS_DIR}

  curl -O http://ftp.flybase.org/releases/FB2022_01/dmel_r6.44/fasta/dmel-all-transcript-r6.44.fasta.gz || { echo "transcriptome download failed" ; exit 1; }

else
  echo "Transcriptome file found; skipping transcriptome download step"
fi

#########################
# FASTP Quality Control #
#########################

for FQ1 in ${DATA_RAW}/*.1.sub.fastq.gz
 do

   sample=$(basename ${FQ1} .1.sub.fastq.gz)

   if [[ ! -f "${DATA_FILT}/${sample}.1.filt.fastq.gz" ]]; then
     # options: -f = file
   	echo "Starting QC for sample: ${sample}"

     fastp -i ${DATA_RAW}/${sample}.1.sub.fastq.gz \
           -I ${DATA_RAW}/${sample}.2.sub.fastq.gz \
           -o ${DATA_FILT}/${sample}.1.filt.fastq.gz \
           -O ${DATA_FILT}/${sample}.2.filt.fastq.gz \
           -h ${FASTP_REPORTS_DIR}/${sample}.fastp.html \
           -j ${FASTP_REPORTS_DIR}/${sample}.fastp.json \
           -w 8 \
           --detect_adapter_for_pe \
           --correction \
           --cut_tail \
           --cut_window_size 5 \
           --cut_mean_quality 30 \
           --overrepresentation_analysis || { echo "fastp failed" ; exit 1; }
            # see fastp --help for option definitions
   else
     echo "Filtered ${sample} file found; skipping fastp step"
   fi

 done


###################
# MULTIQC Summary #
###################

if [[ ! -f "${FASTP_REPORTS_DIR}/multiqc_report.html" ]]; then
  # options: -f = file
	echo "Generating MULTIQC Summary Report"

  multiqc ${FASTP_REPORTS_DIR} -o ${FASTP_REPORTS_DIR} || { echo "multiqc failed" ; exit 1; }
  # options: -o = output directory
else
  echo "Multiqc_report found; skipping summary step"
fi




###################################
#  Index Reference Transcriptome  #
###################################

# REF_GENOME=${REFS_DIR}/dmel-all-transcript-r6.44.fasta.gz

# if [[ ! -d "${REFS_DIR}/dmel_idx" ]]; then
#   # options: -d = directory, containing index files
# 	echo "Indexing Reference Transcriptome"
#
#   salmon index -t ${REF_GENOME} -i ${REFS_DIR}/dmel_idx || { echo "indexing failed" ; exit 1; }
#   # options: -t = transcriptome -i = index
# else
#   echo "Index found; skipping indexing step"
# fi



###########################
#  Quantify Sample Reads  #
###########################

# INDEX=${REFS_DIR}/dmel_idx

# for FQ1 in ${DATA_FILT}/*.1.filt.fastq.gz
#   do
#
#     sample=$(basename ${FQ1} .1.filt.fastq.gz)
#
# 		if [[ ! -d "${SALMON_DIR}/${sample}_quant" ]]; then
# 			echo "Quantifying sample ${sample}"
#
#     	salmon quant -i ${INDEX} \
# 								 	 -l A \
#                  	 -1 ${DATA_FILT}/${sample}.1.filt.fastq.gz \
#                    -2 ${DATA_FILT}/${sample}.2.filt.fastq.gz \
#                    -p 8 \
#                    --validateMappings \
#                    -o ${SALMON_DIR}/${sample}_quant
# 		else
# 			echo "Quantified file found; skipping quant step"
# 		fi
#
# done
