#!/usr/bin/env bash

# Downloads example data subsampled from Everman et al Genetics 2021 and the D. melanogaster transcriptome file

# Instructions:
# sh STEP2_DownloadData.sh


# Establish environmental variables:
echo "Sourcing the config file"
source ~/Downloads/RNAseq_Pipeline/scripts/STEP1_RNAseq_config.sh


#####################################
# Download SAMPLE DATA from github: #
#####################################
echo "Downloading Data from GitHub"

cd ${DATA_RAW}
wget -i https://raw.githubusercontent.com/ereverman/RNAseq_TeachingDemo/main/SRR_urls.txt || { echo "data download failed" ; exit 1; }

mv SRR_urls.txt ${SCRIPTS_DIR}


######################################################
# Download TRANSCRIPTOME for salmon pseudoalignment: #
######################################################

if [[ ! -f "${REFS_DIR}/dmel-transcriptome.fasta.gz" ]]; then
	echo "Downloading Reference Transcriptome"

  wget -O ${REFS_DIR}/dmel-transcriptome.fasta.gz http://ftp.flybase.org/releases/current/dmel_r6.44/fasta/dmel-all-transcript-r6.44.fasta.gz || { echo "transcriptome download failed" ; exit 1; }

else
  echo "Transcriptome file found; skipping download step"
fi
