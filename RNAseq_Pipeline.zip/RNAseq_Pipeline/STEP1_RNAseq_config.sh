# Project directory template for Bioinformatics Teaching Demonstration (April 3-5 University of Kentucky, Department of Entomology)

# RNAseq config template

# Instructions:
# sh STEP1_RNAseq_config.sh


# Assign project-specific variables
PROJECT="RNAseq_Pipeline"
PROJECT_DIR=~/Downloads/RNAseq_Pipeline


# Assign PROJECT_DIR subdirectories

# DATA_DIR
DATA_DIR=${PROJECT_DIR}/data
DATA_RAW=${DATA_DIR}/raw
DATA_FILT=${DATA_DIR}/filtered

# REFS_DIR
REFS_DIR=${PROJECT_DIR}/transcriptome

# RESULTS_DIR
RESULTS_DIR=${PROJECT_DIR}/results
FASTP_REPORTS_DIR=${RESULTS_DIR}/fastp_reports
SALMON_DIR=${RESULTS_DIR}/salmon
FIGURES_DIR=${RESULTS_DIR}/figures
ANALYSIS_DIR=${RESULTS_DIR}/DE_analysis

# SCRIPTS_DIR
SCRIPTS_DIR=${PROJECT_DIR}/scripts

# DOCS_DIR
DOCS_DIR=${PROJECT_DIR}/docs

# Create directories
mkdir -p ${DATA_DIR} \
         ${DATA_RAW} \
         ${DATA_FILT} \
         ${REFS_DIR} \
         ${RESULTS_DIR} \
         ${SALMON_DIR} \
         ${FIGURES_DIR} \
         ${ANALYSIS_DIR} \
         ${FASTP_REPORTS_DIR} \
         ${SCRIPTS_DIR} \
         ${DOCS_DIR} \


# Clean up
if [[ ! -f "${SCRIPTS_DIR}/STEP2_RNAseq_Pipeline.sh" ]]; then
	echo "Cleaning up"

  mv ${PROJECT_DIR}/STEP*.sh ${SCRIPTS_DIR}
  mv ${PROJECT_DIR}/*.R ${SCRIPTS_DIR}
  mv ${PROJECT_DIR}/SRR_urls.txt ${SCRIPTS_DIR}
  mv ${PROJECT_DIR}/SampleList.txt ${ANALYSIS_DIR}
  mv ${PROJECT_DIR}/RawCountData.txt ${ANALYSIS_DIR}
  mv ${PROJECT_DIR}/RNAseq_Analysis.html ${ANALYSIS_DIR}
  mv ${PROJECT_DIR}/SampleSyllabus* ${DOCS_DIR}
  mv ${PROJECT_DIR}/README* ${DOCS_DIR}

else
  echo "Clean up complete; skipping clean up step"
fi
