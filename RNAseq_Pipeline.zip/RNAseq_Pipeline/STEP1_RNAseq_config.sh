# Project directory template for Bioinformatics Teaching Demonstration (April 3-5 University of Kentucky, Department of Entomology)

# RNAseq config template

# Instructions:
# Create local project directory: ~/Desktop/Bioinformatics_Teaching_Demo
# Change lines 14, 18, and 19
# Move config file to SCRIPTS_DIR/


# Assign project-specific variables
PROJECT="RNAseq_Pipeline"
PROJECT_DIR=~/Downloads/RNAseq_Pipeline
REF_GENOME=${REFS_DIR}/dmel-transcriptome.fasta.gz
INDEX=${REFS_DIR}/dmel_idx

# Assign PROJECT_DIR subdirectories

# DATA_DIR
DATA_DIR=${PROJECT_DIR}/data
DATA_RAW=${DATA_DIR}/raw
DATA_FILT=${DATA_DIR}/filtered

# REFS_DIR
REFS_DIR=${PROJECT_DIR}/transcriptome

# RESULTS_DIR
RESULTS_DIR=${PROJECT_DIR}/results
FASTP_REPORTS_DIR=${RESULTS_DIR}/fastp_reports
SALMON_DIR=${RESULTS_DIR}/salmon
FIGURES_DIR=${RESULTS_DIR}/figures
ANALYSIS_DIR=${RESULTS_DIR}/DE_analysis

# SCRIPTS_DIR
SCRIPTS_DIR=${PROJECT_DIR}/scripts


# Create directories
mkdir -p ${DATA_DIR} \
         ${DATA_RAW} \
         ${DATA_FILT} \
         ${REFS_DIR} \
         ${RESULTS_DIR} \
         ${SALMON_DIR} \
         ${FIGURES_DIR} \
         ${ANALYSIS_DIR} \
         ${FASTP_REPORTS_DIR} \
         ${SCRIPTS_DIR} \
