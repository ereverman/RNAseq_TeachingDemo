#!/bin/bash

# INSTRUCTIONS:
# Modify template and save as STEP3_RNAseq_Pipeline.sh


echo "Sourcing the config file"
source ~/Downloads/RNAseq_Pipeline/scripts/STEP1_RNAseq_config.sh


#########################
# FASTP Quality Control #
#########################

#fastp -i SAMPLE.1.sub.fastq.gz \
#      -I SAMPLE.2.sub.fastq.gz \
#      -o SAMPLE.1.filt.fastq.gz \
#      -O SAMPLE.2.filt.fastq.gz \
#      -h SAMPLE.fastp.html \
#      -j SAMPLE.fastp.json \
#      -w 8 \
#      --detect_adapter_for_pe \
#      --correction \
#      --cut_tail \
#      --cut_window_size 5 \
#      --cut_mean_quality 30 \
#      --overrepresentation_analysis


###################
# MULTIQC Summary #
###################


#multiqc




###################################
#  Index Reference Transcriptome  #
###################################


#salmon index -t TRANSCRIPTOME.fasta.gz -i INDEX




###########################
#  Quantify Sample Reads  #
###########################


#salmon quant -i INDEX \
#						 -l A \
#						 -1 SAMPLE.1.filt.fastq.gz \
#						 -2 SAMPLE.2.filt.fastq.gz \
#						 -p 8 \
#						 --validateMappings \
#						 -o SAMPLE_quant
